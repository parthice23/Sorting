// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Sorting>

package projects.project7.cards;

import projects.project7.cards.PlayingCard;

public interface HandOfCards {
	public void addCard(PlayingCard c);
	public void printHand();
}
