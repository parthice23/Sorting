// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Sorting>

package projects.project7.csc205;

import java.util.ArrayList;
import java.util.List;

public class Sorting {

	// Helper methods
	// These operations will occur multiple times in our sorting methods,
	//   so we add methods for them here

	private static <T extends Comparable<T>> boolean less_than(T a, T b) {
		return (a.compareTo(b) < 0);
	}
	private static <T extends Comparable<T>> boolean less_than_equal(T a, T b) {
		return (a.compareTo(b) <= 0);
	}
	private static <T extends Comparable<T>> boolean greater_than(T a, T b) {
		return (a.compareTo(b) > 0);
	}
	private static void swap(Object[] a, int ii, int jj) {
		Object swap = a[ii];
		a[ii] = a[jj];
		a[jj] = swap;
	}
	public static <T extends Comparable<T>> 
	boolean isSorted(T[]data){
		return isSorted(data, 0, data.length-1);
	}
	public static <T extends Comparable<T>> 
	boolean isSorted(T[]data, int min, int max){
		for (int ii=min+1; ii<=max; ii++) {
			if (less_than(data[ii], data[ii-1]))
				return false;
		}
		return true;
	}

	// Selection Sort
	public static <T extends Comparable<T>> 
		void selectionSort (T[] data) {
		selectionSort (data, 0, data.length-1);
	}

	public static <T extends Comparable<T>> 
		void selectionSort (T[] data, int min, int max) {

		int indexOfSmallest;  // Smallest element found this pass
		
		min = Math.max(min, 0);
		max = Math.min(max, data.length-1);
		
		// ii is the starting point for each pass
		for(int next=min; next <= max; next++ ) {
            indexOfSmallest = next;
            for (int scan=next+1; scan<=max; scan++) {
            	if (less_than(data[scan], data[indexOfSmallest])) {
            		indexOfSmallest = scan;
            	}
            }
            swap(data, indexOfSmallest, next);
		}

	}
	
    public static <T extends Comparable<T>> 
	void insertionSort(T[] data) {
    	insertionSort(data, 0, data.length-1);
    }

    public static <T extends Comparable<T>> 
	void insertionSort(T[] data, int min, int max)
    {
    	int start = Math.max(min,  1);
    	int end = Math.min(max,  data.length-1);
    	
        for (int current = start; current <= end; current++)
        {
            int position = current;
			
            // shift larger values to the right 
            while (position > 0 && greater_than(data[position-1],data[position]))
            {
                swap(data, position, position-1);
                position--;
            }
        }
    }

    public static <T extends Comparable<T>> 
	void bubbleSort(T[] data) {
    	bubbleSort(data, 0, data.length-1);
    }
    public static <T extends Comparable<T>> 
	void bubbleSort(T[] data, int min, int max) {
        int position, scan;
        
		min = Math.max(min, 0);
		max = Math.min(max, data.length-1);
		
        // position is the "stopping point" for each pass
        for (position = max; position >= min; position--)
        {
            for (scan = 0; scan < position; scan++)
            {
                if (greater_than(data[scan],data[scan+1]))
                    swap(data, scan, scan + 1);
            }
        }
    }

    
	public static <T extends Comparable<T>>
	void mergeSort(T[] data) {
		mergeSort(data, 0, data.length-1);
	}

	private static <T extends Comparable<T>>
	void mergeSort(T[] data, int min, int max) {
		if (min < max)
		{
			int mid = min + ((max - min) / 2);
			mergeSort(data, min, mid);
			mergeSort(data, mid+1, max);
			merge(data, min, mid, max);
		}
	}
	
	private static <T extends Comparable<T>>
	void merge(T[] data, int first, int mid, int last) {
		T[] temp = (T[])(new Comparable[data.length]);  // temp array
		
		// The two subarrays have already been sorted
		int first1 = first, last1 = mid;   // endpoints of first subarray
		int first2 = mid+1, last2 = last;  // endpoints of second subarray
		int index = first1;  // next index open in temp array
		
		//  Copy smaller item from each subarray into temp until one
		//  of the subarrays is exhausted
		// while both sub arrays have items left
		while (first1 <= last1 && first2 <= last2)
		{
			if (less_than(data[first1],data[first2]))
			{
				temp[index] = data[first1];
				first1++;
			}
			else
			{
				temp[index] = data[first2];
				first2++;
			}
			index++;
		}
		
		// Only one of the while loops below will execute
		//  Copy remaining elements from first subarray, if any
		while (first1 <= last1)
		{
			temp[index] = data[first1];
			first1++;
			index++;
		}
		
		//  Copy remaining elements from second subarray, if any
		while (first2 <= last2)
		{
			temp[index] = data[first2];
			first2++;
			index++;
		}
		
		//  Copy merged data into original array
		for (index = first; index <= last; index++)
			data[index] = temp[index];
	}

	public static <T extends Comparable<T>> 
	void quickSort(T[] data) {
		quickSort(data, 0, data.length-1);
	}

	private static <T extends Comparable<T>> 
	void quickSort(T[] data, int min, int max) {
		if (min < max)
		{
			// create partitions
			int indexofpartition = partition(data, min, max);
			
			// sort the left partition (lower values)
			quickSort(data, min, indexofpartition - 1);
			
			// sort the right partition (higher values)
			quickSort(data, indexofpartition + 1, max);
		}
	}

	private static <T extends Comparable<T>> 
	int partition(T[] data, int min, int max) {
		T partitionelement;
		int left, right;
		int middle = min + ((max - min) / 2);
		
		// use the middle data value as the partition element
		partitionelement = data[middle];
		// move it out of the way for now
		swap(data, middle, min);
		
		left = min;
		right = max;
		
		while (left < right)
		{
			// search for an element that is > the partition element
			while (left < right && less_than_equal(data[left],partitionelement))
				left++;
			
			// search for an element that is < the partition element
			while (greater_than(data[right], partitionelement))
				right--;
			
			// swap the elements
			if (left < right)
				swap(data, left, right);
		}
		
		// move the partition element into place
		swap(data, min, right);
		
		return right;
	}

	// Project 7 - Complete the following methods
	
	//sort(array) should take an array of Comparable objects as a parameter and 
	//sort it in place. 
	public static <T extends Comparable<T>> 
	void sort(T[] data) {
		
		//initailize the variables to use in the loops
		//first variable
		int valuenumberone;
		valuenumberone=0;
		//second variable
        int datalength;
        datalength = data.length;
        //and then you want to subtract it by one in order to sort
        int valuenumbertwo;
        valuenumbertwo = datalength - 1; 

        while (true){
            //beginning loop to check which number is smaller and bigger
        	int firstloopvalue;
        	firstloopvalue = valuenumberone;
        	
        	//sort(array) should take an array of Comparable objects as a parameter and 
        	//sort it in place
        	for (firstloopvalue = valuenumberone; firstloopvalue < valuenumbertwo; firstloopvalue++){
            	//use if statement to see which value is greater 
            	int othervalue;
            	othervalue = firstloopvalue+1;
                if (greater_than(data[firstloopvalue], data[othervalue])){
                	//use swap
                    swap(data, firstloopvalue, othervalue);
                }
            }
            //have to use break if the data is stopped.
            if (isSorted(data)){
                break;
            }
            //using -= to make sure the numbers are smaller
            valuenumbertwo-=1;

            // do same thing as other loop now opposite way
            int secondloopvalue;
            int secondvalue;
            secondvalue = valuenumbertwo-1;
            
            //sort(array) should take an array of Comparable objects as a parameter and 
        	//sort it in place
            for (secondloopvalue = secondvalue; secondloopvalue >= valuenumberone; secondloopvalue--){
            	int othervaluetwo;
            	othervaluetwo = secondloopvalue+1;
                if (greater_than(data[secondloopvalue], data[othervaluetwo])){
                	//use swap
                    swap(data, secondloopvalue, othervaluetwo);
                }
            }
            //have to use break if the data is stopped.
            if (isSorted(data)){
                break;
            }
            //using += to make sure the numbers are smaller
            valuenumberone+=1;
        }
    }
	
//cutoff_qsort(array) should implement a quick sort, 
//but once the partition reaches a small enough size, 
//uses another sorting technique that is more efﬁcient on smaller arrays.
	public static <T extends Comparable<T>> 
	void cutoff_qsort(T[] data) {
		   //initialize variable and use the correct equation to put into qsort	
		   int distance;
		   distance = data.length;
		   int values;
		   values = distance - 1;
		   int div;
		   div = (distance/3);
		   int totals;
		   totals = distance - div;
		   int zeros;
		   zeros = 0;
		   
		   cutoff_qsort(data, zeros, values, totals);
	}

//cutoff_qsoft(array, n) same as above but uses n as the cutoff size.
	public static <T extends Comparable<T>> 
	void cutoff_qsort(T[] data, int cutoff) {
			//initialize variable and use the correct equation to put into qsort
			int distanceone;
			distanceone = data.length; 
			int valuesone;
			valuesone = distanceone - 1;
			int zeros;
			zeros = 0;
			cutoff_qsort(data, zeros, valuesone, cutoff);
	}
	
//cutoff_qsort(array) should implement a quick sort, 
//but once the partition reaches a small enough size,
//uses another sorting technique that is more efﬁcient on smaller arrays.
	private static <T extends Comparable<T>>
	//changed variables from min to smallest and
	// changed from max to largest because it makes it easier for me
	// to focus on it.
	void cutoff_qsort(T[] data, int smallest, int largest, int cutoff) {
		//if the smallest value is less than largervalue
		//also if the range is larger than the cutoff
		int range;
		range = largest - smallest; 
		if (range > cutoff && smallest < largest)
	       {
	           //need to make a partition in order to sort the number using the parameters
	           int normals;
	           normals = partition(data, smallest, largest);
	           // use this partition in order to get the larger numbers
	           int large;
	           large = normals + 1;
	           cutoff_qsort(data, large, largest, cutoff);
	           //use this partition in order to get the small numbers
	           int small;
	           small = normals - 1;
	           cutoff_qsort(data, smallest, small, cutoff);
	          
	       }
		//if the smallest value is less than largest value
		//but in this case the array would be smaller
		//since the array is smaller use the bubblesort method that was already 
		//given in this templete for us
		//bubbleSort(data, 0, data.length-1);
	       else if (smallest < largest)
	       {
	    	 //if the smallest value is less than largest value
	    	 //bubbleSort(data, 0, data.length-1);
	    	 //we can now use the bubblesort for the smaller arrays
	           bubbleSort(data, smallest, largest);
	       }
		
	}
	     
	       
	
	
	
	

//closest Pair
//closestPair(array) returns an ArrayList with the two closest elements of array 
	public static 
	List<Integer> closestPair(Integer[] data) {
		List<Integer> ret = new ArrayList<Integer>();
		   //initialize variables
		   int smallest;
		   smallest = 0;
	       int largest;
	       largest = data.length-1;
	       //use add function in order to help find difference 
	       int zero = 0;
	       ret.add(data[zero]);
	       int one = 1; 
	       ret.add(data[one]);
	       //find the difference between the numbers
	       int  distancebetweenNumbers; 
	       //subtract
	       distancebetweenNumbers = Math.abs(data[one]-data[zero]);
	  
	      
	       // use loop to see which values are closest to each other
	       //initailize variables
	       int stoppervalue; 
	       int number;
	       //start loop
	       for (stoppervalue = largest; stoppervalue >= smallest; stoppervalue--){
	    	   for (number = 0; number < stoppervalue; number++){
	    		 //initailize variables
	    		   int values;
	    		   values = Math.abs(data[number+1]-data[number]);
	    		  //use if statement to return back the corrects numbers in the ranges
	    		   if (values < distancebetweenNumbers) {
	    			   distancebetweenNumbers = values;
	    			   ret.clear();
	    			   //return number
	    			   ret.add(data[number]);
	    			   //return larger value
	    			   int largervalue;
	    			   largervalue = number+1;
	    			   ret.add(data[largervalue]);
	    		   }
	    	   }
	       }
	return ret;
	   }
			
	}

