// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Sorting>

package projects.project7.cards;
import java.util.ArrayList;
import java.util.Random;

public class Deck {
	private ArrayList<PlayingCard> cards;
	private Random rand;

	public Deck(int n) {
		super();
		rand = new Random();
		cards = new ArrayList<PlayingCard>(n);
		for (int suite = 1; suite <= 4; suite ++)
			for (int rank = 1; rank <= 13; rank ++) {
				if ((suite - 1) * 13 + rank <= n) { 
				  cards.add(new PlayingCard(rank, suite));
				}
			}
	}
	
	public PlayingCard dealOne() {
		return cards.get(rand.nextInt(52));
	}
	
	public String toString(){
		String ret = "";
		for (PlayingCard card : cards){
			ret += card + " ";
		}
		ret += "\n";
		return ret;
	}

//Create a method called shuffle() in the Deck class which shufﬂes the deck using 
//the method we discussed in class (sorting an array of random numbers 
//and swapping in the card array each time you swap in the random array). 
	public void shuffle() {
		//using the PlayingCard dealOne() to get a number for the card
		   PlayingCard decks;
		//use .size to return the cards back
		   int returncard;
		   returncard = cards.size();
	    //use loop to repeat and print out random cards
		   int value;
		   for (value = 0; value < returncard; value++) {
			   //use random function to get random number for cards
			   int card;
			   card = returncard - value; 
			   int arbitary;
			   arbitary = value + (int)(Math.random()*card);
			   //return the cards so they can be printed out
			   decks = cards.get(arbitary);
			   //cards
			   cards.set(value,decks);
			   cards.set(arbitary,cards.get(value));

		   }

	}
	
}
